// Stayton Credit App — API (new build)
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

const cfg = {
  business: {
    company: "Stayton Credit Repair",
    slogan: "World’s Best Credit Repair",
    owner: "Joseph Stayton",
    email: "staytoncreditrepair@gmail.com",
    phone: "",
    address: "8500 Harwood Rd",
    city_state_zip: "North Richland Hills, TX 76180"
  },
  pricing: {
    audit_fee: 150,
    monthly_fee: 99,
    inquiries_free: 10,
    inquiry_fee_after: 10,
    notes: "Timelines vary by issue complexity. Edit in server.js or move to a config file."
  }
};

function appendJSON(file, obj){
  const p = path.join(DATA_DIR, file);
  let arr = [];
  if (fs.existsSync(p)){
    try{ arr = JSON.parse(fs.readFileSync(p, 'utf8') || '[]'); } catch(e){ arr = []; }
  }
  arr.push({ ...obj, _ts: new Date().toISOString() });
  fs.writeFileSync(p, JSON.stringify(arr, null, 2));
}

// Health/ping
app.get('/api/ping', (_, res) => res.json({ ok:true, message:'pong' }));

// Business/pricing info
app.get('/api/info', (_, res) => res.json({ ok:true, business: cfg.business, pricing: cfg.pricing }));
app.get('/api/pricing', (_, res) => res.json({ ok:true, pricing: cfg.pricing }));

// Lead capture
app.post('/api/lead', (req, res) => {
  const lead = req.body || {};
  appendJSON('leads.json', lead);
  res.json({ ok:true, message:'Lead saved', lead });
});

// Dispute tracker
app.post('/api/dispute', (req, res) => {
  const dispute = req.body || {};
  appendJSON('disputes.json', dispute);
  res.json({ ok:true, message:'Dispute saved', dispute });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Stayton API listening on :' + PORT));
