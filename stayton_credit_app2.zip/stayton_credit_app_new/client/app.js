// Frontend logic for Stayton Credit App (new build)
const API_BASE = (window.API_BASE || 'http://localhost:3000').replace(/\/$/, '');
document.getElementById('year').textContent = new Date().getFullYear();

// Inject pricing + business info from local config and API fallback
async function hydrate() {
  try {
    const localCfg = await fetch('./config.json').then(r=>r.json());
    setPricing(localCfg.pricing);
    setBiz(localCfg.business);
  } catch(e) { /* ignore */ }

  try {
    const res = await fetch(API_BASE + '/api/info');
    if (res.ok) {
      const data = await res.json();
      if (data.business) setBiz(data.business);
      if (data.pricing) setPricing(data.pricing);
    }
  } catch(e) { /* offline ok */ }
}
hydrate();

function setPricing(p){
  if(!p) return;
  const $ = (id)=>document.getElementById(id);
  if($('p_audit')) $('p_audit').textContent = '$' + (p.audit_fee ?? '—');
  if($('p_monthly')) $('p_monthly').textContent = '$' + (p.monthly_fee ?? '—') + '/mo';
  if($('p_free')) $('p_free').textContent = (p.inquiries_free ?? '—') + ' inquiries';
  if($('p_after')) $('p_after').textContent = '$' + (p.inquiry_fee_after ?? '—') + ' each';
  if($('p_notes')) $('p_notes').textContent = p.notes || '';
}

function setBiz(b){
  const el = document.getElementById('biz');
  if(!el || !b) return;
  el.innerHTML = `<div><strong>${b.company||''}</strong></div>
    <div>${b.owner||''}</div>
    <div>${b.address||''}</div>
    <div>${b.city_state_zip||''}</div>
    <div>${b.phone||''}</div>
    <div><a href="mailto:${b.email||''}">${b.email||''}</a></div>`;
}

// Lead form
const leadForm = document.getElementById('leadForm');
const leadMsg = document.getElementById('leadMsg');
leadForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  leadMsg.textContent = 'Submitting…';
  const data = Object.fromEntries(new FormData(leadForm).entries());
  try {
    const res = await fetch(API_BASE + '/api/lead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const json = await res.json();
    leadMsg.textContent = json.message || 'Saved!';
    leadForm.reset();
  } catch (err) {
    leadMsg.textContent = 'Error sending lead: ' + err.message;
  }
});

// Disputes
const disputeForm = document.getElementById('disputeForm');
const disputeMsg = document.getElementById('disputeMsg');
const list = document.getElementById('disputes');

disputeForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  disputeMsg.textContent = 'Saving…';
  const data = Object.fromEntries(new FormData(disputeForm).entries());
  try {
    const res = await fetch(API_BASE + '/api/dispute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const json = await res.json();
    disputeMsg.textContent = json.message || 'Added!';
    addItem(json.dispute || data);
    disputeForm.reset();
  } catch (err) {
    disputeMsg.textContent = 'Error: ' + err.message;
  }
});

function addItem(d){
  const el = document.createElement('div');
  el.className = 'item';
  el.innerHTML = '<strong>' + (d.creditor||'Unknown') + '</strong> — ' + (d.issue||'') +
                 '<div class="muted">Ref: ' + (d.account||'-') + '</div>';
  list.prepend(el);
}
