const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const morgan = require('morgan');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

// --- in-memory demo store ---
let disputes = [
  { id: 1, bureau: 'Experian', type: 'Incorrect Account', description: 'Wrong balance on account #1234', status: 'Submitted' },
];

// --- auth middleware ---
function auth(req, res, next) {
  const hdr = req.headers.authorization || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Missing token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    return next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

// --- routes ---
app.post('/auth/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ message: 'Email and password required' });
  // Demo-only: accept any email/password; mark owner if matches
  const user = { id: 1, email, name: email === 'staytoncreditrepair@gmail.com' ? 'Joseph Stayton' : 'Client' };
  const token = jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user });
});

app.get('/disputes', auth, (req, res) => {
  res.json(disputes);
});

app.post('/disputes', auth, (req, res) => {
  const { bureau, type, description } = req.body || {};
  if (!bureau || !type || !description) return res.status(400).json({ message: 'bureau, type, description required' });
  const id = disputes.length ? (disputes[disputes.length - 1].id + 1) : 1;
  const record = { id, bureau, type, description, status: 'Submitted' };
  disputes.push(record);
  res.status(201).json(record);
});

app.listen(PORT, () => {
  console.log(`API running on http://localhost:${PORT}`);
});
