# Stayton Credit Repair — API
Simple Express server with JWT auth and in-memory disputes.

## Quick start
1) Install Node.js LTS.
2) `npm install`
3) Copy `.env.example` to `.env` and edit values.
4) `npm run start` (defaults to http://localhost:3001)

## Endpoints
- POST /auth/login {email,password} → {token,user}
- GET /disputes (auth: Bearer token) → list
- POST /disputes (auth) {bureau,type,description} → created
