import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { Colors } from './theme/colors';

import SignInScreen from './src/screens/SignInScreen';
import HomeScreen from './src/screens/HomeScreen';
import DisputesScreen from './src/screens/DisputesScreen';
import NewDisputeScreen from './src/screens/NewDisputeScreen';
import SupportScreen from './src/screens/SupportScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="light" backgroundColor={Colors.navy} />
      <Stack.Navigator
        initialRouteName="SignIn"
        screenOptions={{
          headerStyle: { backgroundColor: Colors.navy },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: '700' },
        }}
      >
        <Stack.Screen name="SignIn" component={SignInScreen} options={{ title: "Stayton Credit Repair" }} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Disputes" component={DisputesScreen} />
        <Stack.Screen name="NewDispute" component={NewDisputeScreen} options={{ title: "Add Dispute" }} />
        <Stack.Screen name="Support" component={SupportScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
