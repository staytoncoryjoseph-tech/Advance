export const Colors = {
  navy: '#0B1B3B',
  gold: '#CDA434',
  white: '#FFFFFF',
  bg: '#F7F8FB',
  text: '#1A1A1A',
};
