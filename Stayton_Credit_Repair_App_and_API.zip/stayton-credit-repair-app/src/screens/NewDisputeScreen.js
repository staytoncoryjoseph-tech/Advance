import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Colors } from '../../theme/colors';
import { createDispute } from '../api';

export default function NewDisputeScreen({ route, navigation }) {
  const { token, onSaved } = route.params;
  const [bureau, setBureau] = useState('Experian');
  const [type, setType] = useState('Incorrect Account');
  const [description, setDescription] = useState('');

  const onSubmit = async () => {
    try {
      if (!description.trim()) {
        Alert.alert('Missing info', 'Please describe the issue');
        return;
      }
      await createDispute(token, { bureau, type, description });
      onSaved && onSaved();
      navigation.goBack();
    } catch (e) {
      Alert.alert('Could not save', e?.response?.data?.message || 'Try again later');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Credit Bureau</Text>
      <TextInput style={styles.input} value={bureau} onChangeText={setBureau} placeholder="Experian / Equifax / TransUnion" />
      <Text style={styles.label}>Dispute Type</Text>
      <TextInput style={styles.input} value={type} onChangeText={setType} placeholder="Incorrect Account / Personal Info / Inquiry" />
      <Text style={styles.label}>Description</Text>
      <TextInput style={[styles.input, styles.textarea]} value={description} onChangeText={setDescription} placeholder="Explain the issue…" multiline numberOfLines={6} />

      <TouchableOpacity style={styles.button} onPress={onSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor: Colors.bg, padding: 16 },
  label: { marginTop: 8, marginBottom: 4, fontWeight:'700', color: Colors.navy },
  input: { backgroundColor:'#fff', borderRadius: 12, padding: 12, borderWidth:1, borderColor:'#eee' },
  textarea: { height: 140, textAlignVertical:'top' },
  button: { backgroundColor: Colors.gold, padding: 14, borderRadius: 12, alignItems:'center', marginTop: 16 },
  buttonText: { color: Colors.navy, fontWeight:'800' },
});
