import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, RefreshControl } from 'react-native';
import { Colors } from '../../theme/colors';
import { getDisputes } from '../api';

export default function DisputesScreen({ navigation, route }) {
  const { token } = route.params;
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const data = await getDisputes(token);
      setItems(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Your Disputes</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('NewDispute', { token, onSaved: load })}>
          <Text style={styles.addBtnText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={items}
        keyExtractor={(it) => String(it.id)}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{item.bureau} • {item.type}</Text>
            <Text style={styles.cardText}>{item.description}</Text>
            <Text style={styles.status}>Status: {item.status}</Text>
          </View>
        )}
        ListEmptyComponent={!loading && (<Text style={{ textAlign:'center', color:'#666', marginTop:20 }}>No disputes yet.</Text>)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor: Colors.bg, padding: 16 },
  headerRow: { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom: 8 },
  title: { fontSize: 22, fontWeight:'800', color: Colors.navy },
  addBtn: { backgroundColor: Colors.gold, paddingHorizontal: 14, paddingVertical:10, borderRadius: 10 },
  addBtnText: { color: Colors.navy, fontWeight:'800' },
  card: { backgroundColor:'#fff', borderRadius: 14, padding: 14, marginVertical: 6, borderWidth:1, borderColor:'#eee' },
  cardTitle: { fontSize: 16, fontWeight:'800', color: Colors.navy },
  cardText: { marginTop:6, color:'#444' },
  status: { marginTop:8, fontStyle:'italic', color:'#666' },
});
