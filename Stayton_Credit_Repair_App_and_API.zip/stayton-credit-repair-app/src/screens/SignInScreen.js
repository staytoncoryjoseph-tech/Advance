import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { Colors } from '../../theme/colors';
import { login } from '../api';

export default function SignInScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const onSignIn = async () => {
    try {
      setLoading(true);
      const data = await login(email, password);
      navigation.replace('Home', { token: data.token, user: data.user });
    } catch (e) {
      Alert.alert('Sign in failed', e?.response?.data?.message || 'Check your credentials and API URL');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Stayton Credit Repair</Text>
      <Text style={styles.subtitle}>Sign in to continue</Text>
      <TextInput style={styles.input} placeholder="Email" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
      <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />
      <TouchableOpacity style={styles.button} onPress={onSignIn} disabled={loading}>
        <Text style={styles.buttonText}>{loading ? 'Signing in...' : 'Sign In'}</Text>
      </TouchableOpacity>
      <Text style={styles.footer}>Owner: Joseph Stayton • 8500 Harwood Rd • Navy/Gold/White</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg, padding: 24, justifyContent: 'center' },
  title: { fontSize: 28, fontWeight: '800', color: Colors.navy, marginBottom: 8, textAlign: 'center' },
  subtitle: { fontSize: 14, color: '#666', marginBottom: 16, textAlign: 'center' },
  input: { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#eee' },
  button: { backgroundColor: Colors.gold, padding: 14, borderRadius: 12, alignItems: 'center', marginTop: 4 },
  buttonText: { color: Colors.navy, fontWeight: '800' },
  footer: { fontSize: 12, color: '#666', marginTop: 24, textAlign: 'center' },
});
