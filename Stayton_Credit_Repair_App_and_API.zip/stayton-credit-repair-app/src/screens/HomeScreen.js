import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Colors } from '../../theme/colors';

export default function HomeScreen({ navigation, route }) {
  const { token, user } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome, {user?.name || 'Client'}</Text>
      <Text style={styles.subtitle}>Track disputes, book support, and view pricing.</Text>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Disputes', { token })}>
        <Text style={styles.cardTitle}>Dispute Tracker</Text>
        <Text style={styles.cardText}>View and add credit report disputes.</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Support', { token })}>
        <Text style={styles.cardTitle}>Support & Pricing</Text>
        <Text style={styles.cardText}>Chat, contact, and see services.</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg, padding: 20 },
  title: { fontSize: 24, fontWeight: '800', color: Colors.navy, marginBottom: 4 },
  subtitle: { color: '#555', marginBottom: 20 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 18, marginBottom: 12, borderWidth: 1, borderColor: '#eee' },
  cardTitle: { fontSize: 18, fontWeight: '800', color: Colors.navy },
  cardText: { marginTop: 6, color: '#555' },
});
