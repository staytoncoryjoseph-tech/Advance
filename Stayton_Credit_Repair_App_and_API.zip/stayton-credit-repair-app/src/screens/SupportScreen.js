import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '../../theme/colors';

export default function SupportScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Support & Pricing</Text>
      <Text style={styles.text}>• Credit Audit (first meeting): $150</Text>
      <Text style={styles.text}>• Monthly Service: $99/month</Text>
      <Text style={styles.text}>• First 15 inquiries: FREE; $10 each after</Text>
      <Text style={[styles.text, { marginTop: 16 }]}>
        Disclaimer: We do not guarantee specific score changes or outcomes. Timelines vary by item type.
      </Text>
      <Text style={[styles.text, { marginTop: 8 }]}>
        Contact: staytoncreditrepair@gmail.com
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor: Colors.bg, padding: 16 },
  title: { fontSize: 22, fontWeight:'800', color: Colors.navy, marginBottom: 8 },
  text: { color:'#333', marginTop: 6 },
});
