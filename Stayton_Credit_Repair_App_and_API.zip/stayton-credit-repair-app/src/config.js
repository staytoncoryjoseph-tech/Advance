export const BASE_URL = 'http://10.0.2.2:3001'; // Android emulator. iOS simulator: http://localhost:3001
