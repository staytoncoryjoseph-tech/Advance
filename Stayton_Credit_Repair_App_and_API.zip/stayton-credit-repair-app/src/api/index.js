import axios from 'axios';
import { BASE_URL } from '../config';

const api = axios.create({ baseURL: BASE_URL, timeout: 10000 });

export const login = async (email, password) => (await api.post('/auth/login', { email, password })).data;
export const getDisputes = async (token) => (await api.get('/disputes', { headers: { Authorization: `Bearer ${token}` } })).data;
export const createDispute = async (token, payload) => (await api.post('/disputes', payload, { headers: { Authorization: `Bearer ${token}` } })).data;

export default api;
