# Stayton Credit Repair — Mobile App (Expo)
Navy/Gold/White theme. Screens: Sign In, Home, Disputes, New Dispute, Support.

## Quick start
1) Install Node.js LTS.
2) In the `stayton-credit-repair-app` folder: `npm install`
3) Set API URL in `src/config.js` (Android emulator: `http://10.0.2.2:3001`, iOS simulator: `http://localhost:3001`).
4) Start: `npx expo start` then press **a** for Android, **i** for iOS, or scan the QR with Expo Go.

## Build for Play Store (Android AAB)
- Install EAS: `npm i -g eas-cli`
- Run: `eas login` then `eas build -p android --profile production`
- Upload the resulting **.aab** to Google Play Console.
