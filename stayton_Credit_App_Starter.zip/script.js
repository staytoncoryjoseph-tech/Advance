// Basic interactivity and API wiring
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

document.getElementById('ctaBtn')?.addEventListener('click', () => {
  document.getElementById('intake')?.scrollIntoView({ behavior: 'smooth' });
});

const statusEl = document.getElementById('formStatus');
const intakeForm = document.getElementById('intakeForm');
const API_BASE = window.APP_CONFIG?.API_BASE_URL || 'https://example-api.invalid'; // replace with your backend URL

intakeForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  statusEl.textContent = 'Submitting…';
  const formData = new FormData(intakeForm);
  const payload = Object.fromEntries(formData.entries());

  try {
    const res = await fetch(`${API_BASE}/intake`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Network response was not ok');
    statusEl.textContent = 'Thanks! We’ll reach out shortly.';
    intakeForm.reset();
  } catch (err) {
    statusEl.textContent = 'Could not submit. Check API URL in config/app-config.js';
    console.error(err);
  }
});
