// Frontend runtime config — edit this to point the UI at your backend.
window.APP_CONFIG = {
  API_BASE_URL: "https://stayton-api.onrender.com" // e.g., Render/Back4App/Heroku/Cloud Run URL
};
