# Stayton Credit App — Starter

A clean front-end starter for **Stayton Credit Repair** (navy • gold • white). Includes basic sections, intake form, and a simple config to point the UI at your backend.

## Quick Start
1. Open `index.html` in your browser to preview locally.
2. Edit `config/app-config.js` and set `API_BASE_URL` to your deployed backend.
3. Deploy the frontend:
   - **GitHub Pages**: push these files, enable Pages (from `main` branch / root), wait for the green check.
   - **Replit / Netlify / Vercel**: drag‑and‑drop or connect repo and deploy as static site.

## Point the Frontend to Your API
- Change the value in `config/app-config.js`:
```js
window.APP_CONFIG = { API_BASE_URL: "https://YOUR-BACKEND-URL" };
```
- The form POSTs to `POST /intake` on your API.

## Files
- `index.html` — structure & content
- `style.css` — navy/gold/white theme
- `script.js` — basic UX + `fetch` to API
- `config/app-config.js` — set `API_BASE_URL`
- `assets/logo-placeholder.png` — replace with your real logo
- `assets/favicon.png` — site icon

## Notes
- This is a static starter. For a full app, add auth, dashboards, and server endpoints.
- Compliant messaging only; no guarantee of score change.
